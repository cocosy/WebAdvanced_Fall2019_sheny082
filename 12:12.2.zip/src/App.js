import React,{Component} from 'react';
import './App.css';
import Header from './Components/Header/Header'
import Footer from './Components/Footer/Footer'
import Carousel from './Components/Carousel/Carousel'
import Modal from './Components/Modal/Modal'


class App extends Component{
  state = {
    show:false,

    caption:[
      {name: "nam01", num: 0, img: "https://github.com/cocosy/WebAdvanced_Fall2019_sheny082/blob/master/week06_midterm/assets/img/pic-04.png?raw=true"},
      {name:"yeum", num: 1, img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Square_200x200.svg/200px-Square_200x200.svg.png'},
      {name: "N02", num: 2, img: 'https://github.com/cocosy/WebAdvanced_Fall2019_sheny082/blob/master/week06_midterm/assets/img/pic-08.png?raw=true'},
      {name:"yesf", num: 3, img:''},
      {name: "N03", num: 4, img: ''},
      {name:"sdfadsf", num: 5, img: '' },
      {name: "N04city", num: 6, img: ''},
      {name:"hdfsafsd", num: 7, img: ''},
      {name: "N05city", num: 8, img: ''},
      {name:"fsfsafds", num: 9, img: ''},

      {name: "N04city", num: 10, img: ''},
      {name:"hdfsafsd", num: 11, img: ''}
      // {name: "N05city", num: 12, img: ''},
      // {name:"fsfsafds", num: 13, img: ''},
      // {name: "N04city", num: 14, img: ''},
      // {name:"hdfsafsd", num: 15, img: ''},
      // {name: "N05city", num: 16, img: ''},
      // {name:"fsfsafds", num: 17, img: ''},
      // {name: "N04city", num: 18, img: ''},
      // {name:"hdfsafsd", num: 19, img: ''},
      // {name: "N05city", num: 20, img: ''},
      // {name:"fsfsafds", num: 21, img: ''},
      // {name: "N04city", num: 22, img: ''},
      // {name:"hdfsafsd", num: 23, img: ''},

    ]
  };


  showModal = ()=>{
    this.setState({
       show:!this.state.show,
      //  value: this.state.caption[].num,
    });
};




render(){
  

// console.log(this.showModal.info);
  // const items = this.state.projects.map(
  //   (data) => 
  //   <div classNmae="projects">
  //     <h2>{data.name}</h2>
  //     <p>{data.description}</p>
  //     </div> 
  //);

  return (

    <div className="App">
      <Header/>
      {/* <img src = {require("./placeholder.png")} alt="logo"/> */}
    <div onClick = {() => {this.showModal();this.showModal.info = 0 ; this.showModal.title = this.state.caption[0].name; this.showModal.pic = this.state.caption[0].img}}> <Carousel className = 'yellow block-L' title ='White Rabbit Creamy Candy' img = {this.state.caption[0].img}/></div>
    {/* <Modal onClose = {this.showModal} show = {this.state.show}>{this.state.text[num].name}</Modal> */}

    <div onClick = {() => {this.showModal();this.showModal.info = 1; this.showModal.title = this.state.caption[1].name; this.showModal.pic = this.state.caption[1].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[1].name} img ={this.state.caption[1].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 2; this.showModal.title = this.state.caption[2].name; this.showModal.pic = this.state.caption[2].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[2].name} img ={this.state.caption[2].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 3; this.showModal.title = this.state.caption[3].name; this.showModal.pic = this.state.caption[3].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[3].name} img ={this.state.caption[3].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 4; this.showModal.title = this.state.caption[4].name; this.showModal.pic = this.state.caption[4].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[4].name} img ={this.state.caption[4].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 5; this.showModal.title = this.state.caption[5].name; this.showModal.pic = this.state.caption[5].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[5].name} img ={this.state.caption[5].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 6; this.showModal.title = this.state.caption[6].name; this.showModal.pic = this.state.caption[6].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[6].name} img ={this.state.caption[6].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 7; this.showModal.title = this.state.caption[7].name; this.showModal.pic = this.state.caption[7].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[7].name} img ={this.state.caption[7].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 8; this.showModal.title = this.state.caption[8].name; this.showModal.pic = this.state.caption[8].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[8].name} img ={this.state.caption[8].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 9; this.showModal.title = this.state.caption[9].name; this.showModal.pic = this.state.caption[9].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[9].name} img ={this.state.caption[9].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 10; this.showModal.title = this.state.caption[10].name; this.showModal.pic = this.state.caption[10].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[10].name} img ={this.state.caption[10].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 11; this.showModal.title = this.state.caption[11].name; this.showModal.pic = this.state.caption[11].img}}> <Carousel className = 'yellow block-L' title ={this.state.caption[11].name} img ={this.state.caption[11].img}/></div>
    
    
    {/* <div onClick = {() => {this.showModal();this.showModal.info = 3}}> <Carousel className = 'yellow block-L' title ={this.state.caption[3].name} img = {this.state.caption[3].img}/></div> */}
    {/* <div onClick = {() => {this.showModal();this.showModal.info = 4}}> <Carousel className = 'yellow block-L' title ={this.state.caption[4].name} img = {this.state.caption[4].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 5}}> <Carousel className = 'yellow block-L' title ={this.state.caption[5].name} img = {this.state.caption[5].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 6}}> <Carousel className = 'yellow block-L' title ={this.state.caption[6].name} img = {this.state.caption[6].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 7}}> <Carousel className = 'yellow block-L' title ={this.state.caption[7].name} img = {this.state.caption[7].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 8}}> <Carousel className = 'yellow block-L' title ={this.state.caption[8].name} img = {this.state.caption[8].img}/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 9}}> <Carousel className = 'yellow block-L' title ={this.state.caption[9].name} img = {this.state.caption[9].img}/></div> */}
    {/* <div onClick = {() => {this.showModal();this.showModal.info = 10}}> <Carousel className = 'yellow block-L' title ='Wooden Badminton Racket' img = 'https://github.com/cocosy/WebAdvanced_Fall2019_sheny082/blob/master/img/badminton_racket.jpg?raw=true'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 11}}> <Carousel className = 'yellow block-L' title ='Wooden Badminton Racket' img = 'https://github.com/cocosy/WebAdvanced_Fall2019_sheny082/blob/master/img/badminton_racket.jpg?raw=true'/></div>
   
   
    <div onClick = {() => {this.showModal();this.showModal.info = 12}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 13}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 14}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 15}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 16'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 17'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 18'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 19'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 20'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 21'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 22'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = 23'}}> <Carousel className = 'yellow block-S'/></div> */}


    <Modal onClose = {this.showModal} show = {this.state.show} value = {this.showModal.info} title = {this.showModal.title} photo = {this.showModal.pic}></Modal>

 
      
       <Footer/>
    </div>
 
  );
}


// function App() {

//   return (
//     <div className="App">
//       <Header/>
//       <Carousel/>
//       <Footer/>
    
//     </div>
//   );


}

export default App;
