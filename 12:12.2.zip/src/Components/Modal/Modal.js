import React,{Component} from 'react';
import './Modal.css';


class Modal extends Component{

    constructor(props) {
        super(props);
      
        this.state = {
           value:[] ,
           photo:'',
           title :'',
          // changeTwo: "",
          // changeThree: "",
        }
      }
//    state = {
//         veg:[
//           {name: "sprout", age: 2},
//           {name: "soy bean", age: 6},
//           {name: "spinach", age: 4},
//         ]
//       }

    //  value = () =>{
    //      this.props.value();
    //   }

    onClose = ()=>{
        this.props.onClose();
    }


    render(){
        if(!this.props.show){
            return null;
        }

        return(
           <div className= "myModal">
            <div className ="Container"> 
               <h1>{this.props.title}</h1>
               {/* <h3>{this.props.value}</h3> */}
               {/* <div id={if ({this.props.value} === '1') { '' }}>Hello World!</div> */}
               
            <img src = {this.props.photo} alt="img"/>

              <p>
                   {(() => {
                    switch (this.props.value) {
                    case 0:  return "text placeholder 00 This is a game that we used to play when we are a children ";
                    case 1:  return "text placeholder 01 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Penatibus et magnis dis parturient montes nascetur. Ac tincidunt vitae semper quis. Diam donec adipiscing tristique risus nec feugiat.";
                    case 2:  return "text placeholder 02 A condimentum vitae sapien pellentesque habitant morbi tristique senectus et. Sapien et ligula ullamcorper malesuada proin libero nunc consequat. Consectetur adipiscing elit duis tristique sollicitudin nibh sit amet. Adipiscing bibendum est ultricies integer.";
                    case 3:  return "text placeholder 03 Leo integer malesuada nunc vel risus commodo viverra. Et odio pellentesque diam volutpat. Dui nunc mattis enim ut tellus elementum sagittis vitae. Enim neque volutpat ac tincidunt vitae semper quis lectus nulla. Semper quis lectus nulla at volutpat.";
                    case 4:  return "text placeholder 04";
                    case 5:  return "text placeholder 05";
                    case 6:  return "text placeholder 06";
                    case 7:  return "text placeholder 07";
                    case 8:  return "text placeholder 08";
                    case 9:  return "text placeholder 09";
                    case 10:  return "text placeholder 10";
                    case 11:  return "text placeholder 11";
                    default: return "error";
                }
            })()}
          </p>

             <div><span id="close" onClick = {()=>{this.onClose();}} >&#10005;</span></div>
               </div>
           </div> 
        );
    }

}


export default Modal;