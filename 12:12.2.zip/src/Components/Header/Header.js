import React from 'react';
import './Header.css'

const Header  = ()=>{
 
        return(
            <div className = 'header'>
                {/* <span>Title</span> */}
                {/* <div className="title">
                    <ul>
                    <h3>What are you looking for today</h3>
                    
        
                    <h1>Milliennail Supermarket</h1>
                    </ul>
                    </div> */}
              
                    <ul>
                        <li><h3 id= "slogan">Tuesday, Dec. 10th,2019</h3></li>
                        <li ><h2 id= "title">Milliennial Supermarket</h2></li>
                        <ul id = "links">
                        <h3>Weather: Rainy</h3>
                        <h3>Issue 01</h3>
                        <h3>About</h3>
                        </ul>
                    </ul>
             
            </div>
        );

}

export default Header;