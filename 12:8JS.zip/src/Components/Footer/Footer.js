import React from 'react';
import './Footer.css';


const Footer  = ()=>{
 
    return(
        <footer>
            <h3>Milliennial Market@2019</h3> 

            </footer>
    );



    

    }
    
    export default Footer;