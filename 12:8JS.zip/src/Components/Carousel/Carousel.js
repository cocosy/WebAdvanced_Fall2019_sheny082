//import React from 'react';
import React,{Component} from 'react';
import './Carousel.css'

// const Blocks  = ()=>{
 
//     return(
//         <div className = 'blocks'>
//             <div className = 'green block'></div>
//             <div className = 'yellow block'></div>
//             <div className = 'blue block'></div>
//         </div>
//     );

// }

// export default Blocks;



class Blocks extends Component {

    constructor(props) {
      super(props);
    
      this.state = {
        changeOne: "",
        changeTwo: "",
        changeThree: "",
      }
    }
  
  
    boxOneClick = () => {
      this.setState({
        changeOne: "gold"
      })
    }

    boxTwoClick = () => {
        this.setState({
            changeTwo: "gray",
        })
      }

    boxThreeClick = () => {
        this.setState({
            changeThree: "black",
        })
    }  
  
    render() {
      return (
        <div className="blocks">
        <div className = 'green block-L'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-L'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-L'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'green block-L'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-L'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-L'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

 {/* ----------- M --------------------- */}
        <div className = 'green block-M'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-M'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-M'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>
         <div className = 'yellow block-M'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-M'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

       {/* ----------- M --------------------- */}

<div className = 'green block-M'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-M'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-M'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>
         <div className = 'yellow block-M'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-M'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>


       {/* ----------- L --------------------- */}


       <div className = 'green block-L'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-L'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-L'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>
          <div className = 'green block-L'
            style={{backgroundColor: this.state.changeOne}}
             onClick={this.boxOneClick} 
        ></div>
       
        <div className = 'yellow block-L'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div>

        <div className = 'blue block-L'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

         {/* ----------- S --------------------- */}

         <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>
          <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

{/* <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>
          <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div>

        <div className = 'blue block-S'
            style={{backgroundColor: this.state.changeThree}}
            onClick={this.boxThreeClick} 
        ></div> */}




  
        </div>
      );
    }
  }

  export default Blocks;