import React from 'react';
import './Header.css'

const Header  = ()=>{
 
        return(
            <div className = 'header'>
                {/* <span>Title</span> */}
                {/* <div className="title">
                    <ul>
                    <h3>What are you looking for today</h3>
                    
        
                    <h1>Milliennail Supermarket</h1>
                    </ul>
                    </div> */}
              
                    <ul>
                        <h3 id= "slogan">What are you looking for today</h3>
                        <h2 id= "title">Milliennial Supermarket</h2>
                        <ul id = "links">
                        <h3>Link1</h3>
                        <h3>Link2</h3>
                        <h3>Link3</h3>
                        </ul>
                    </ul>
             
            </div>
        );

}

export default Header;