import React from 'react';
import './App.css';
import Header from './Components/Header/Header'
import Footer from './Components/Footer/Footer'
import Carousel from './Components/Carousel/Carousel'

function App() {

  return (
    <div className="App">
      <Header/>
      <Carousel/>
      <Footer/>
    
    </div>
  );
}

export default App;
