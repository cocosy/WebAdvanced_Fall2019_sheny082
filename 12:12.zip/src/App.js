import React,{Component} from 'react';
import './App.css';
import Header from './Components/Header/Header'
import Footer from './Components/Footer/Footer'
import Carousel from './Components/Carousel/Carousel'
import Modal from './Components/Modal/Modal'


class App extends Component{
  state = {
    show:false,

    text:[
      {name: "hiiiiiiiiii"},
      {name:"h2222222iii"}

    ]
  };

  showModal = ()=>{
    this.setState({
       show:!this.state.show,
       info:'',
    });
};




render(){
  

// console.log(this.showModal.info);
  // const items = this.state.projects.map(
  //   (data) => 
  //   <div classNmae="projects">
  //     <h2>{data.name}</h2>
  //     <p>{data.description}</p>
  //     </div>
  //);

  return (

    <div className="App">
      <Header/>
      {/* <img src = {require("./placeholder.png")} alt="logo"/> */}
    <div onClick = {() => {this.showModal();this.showModal.info = '0'}}> <Carousel className = 'yellow block-L'/></div>
    {/* <Modal onClose = {this.showModal} show = {this.state.show}>{this.state.text[num].name}</Modal> */}

    <div onClick = {() => {this.showModal();this.showModal.info = '1'}}> <Carousel className = 'yellow block-L' title ='goodnight' img = 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Square_200x200.svg/200px-Square_200x200.svg.png'  /></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '2'}}> <Carousel className = 'yellow block-L' title ='' img = 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Square_200x200.svg/200px-Square_200x200.svg.png' /></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '3'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '4'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '5'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '6'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '7'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '8'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '9'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '10'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '11'}}> <Carousel className = 'yellow block-L'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '12'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '13'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '14'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '15'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '16'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '17'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '18'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '19'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '20'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '21'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '22'}}> <Carousel className = 'yellow block-S'/></div>
    <div onClick = {() => {this.showModal();this.showModal.info = '23'}}> <Carousel className = 'yellow block-S'/></div>


    <Modal onClose = {this.showModal} show = {this.state.show} value = {Number(this.showModal.info)}>'hiiiii'</Modal>


      
       <Footer/>
    </div>
 
  );
}


// function App() {

//   return (
//     <div className="App">
//       <Header/>
//       <Carousel/>
//       <Footer/>
    
//     </div>
//   );


}

export default App;
