//import React from 'react';
import React,{Component} from 'react';
import './Carousel.css'

// const Blocks  = ()=>{
 
//     return(
//         <div className = 'blocks'>
//             <div className = 'green block'></div>
//             <div className = 'yellow block'></div>
//             <div className = 'blue block'></div>
//         </div>
//     );

// }

// export default Blocks;



class Blocks extends Component {

    constructor(props) {
      super(props);
    
      this.state = {
          title:'',
          img:'',
          className:'',
          changeOne: " "
        // changeTwo: "",
        // changeThree: "",
      }
    }
  
  
    boxOneClick = () => {
      this.setState({
        changeOne: "pink"
      })
    }

    // boxTwoClick = () => {
    //     this.setState({
    //         changeTwo: "gray",
    //     })
    //   }

    // boxThreeClick = () => {
    //     this.setState({
    //         changeThree: "black",
    //     })
    // }  
  
    render() {
      return (
        <div className="blocks">
        <div className = {this.props.className} style={{backgroundColor: this.state.changeOne}} onClick={this.boxOneClick}>
        <img src = {this.props.img} alt ="img"/>
        <h2>{this.props.title}</h2>

        {/* <div className = '02 yellow block-L'
            style={{backgroundColor: this.state.changeTwo}}
            onClick={this.boxTwoClick} 
        ></div> */}

        </div>

        </div>
      );
    }
  }

  export default Blocks;