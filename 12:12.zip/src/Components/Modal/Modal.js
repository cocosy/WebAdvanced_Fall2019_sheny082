import React,{Component} from 'react';
import './Modal.css';


class Modal extends Component{

    constructor(props) {
        super(props);
      
        this.state = {
           value:'',
          // changeTwo: "",
          // changeThree: "",
        }
      }
//    state = {
//         veg:[
//           {name: "sprout", age: 2},
//           {name: "soy bean", age: 6},
//           {name: "spinach", age: 4},
//         ]
//       }

    //  value = () =>{
    //      this.props.value();
    //   }

    onClose = ()=>{
        this.props.onClose();
    }


    render(){
        if(!this.props.show){
            return null;
        }

        return(
           <div className= "myModal">
            <div className ="Container"> 
               <h1>{this.props.children}</h1>
               <h3>{this.props.value}</h3>
               {/* <div id={if ({this.props.value} === '1') { '' }}>Hello World!</div> */}
              <p>
                   {(() => {
                    switch (this.props.value) {
                    case 0:  return "hi";
                    case 1:  return "hii";
                    case 2:  return "hiii";
                    default: return "what";
                }
            })()}
          </p>

               <div><span id="close" onClick = {()=>{this.onClose();}} >&#10005;</span></div>
               </div>
           </div> 
        );
    }

}


export default Modal;